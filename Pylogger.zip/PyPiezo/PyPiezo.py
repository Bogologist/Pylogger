# Load in needed libraries
import os, csv
import pandas as pd, numpy as np

osdir = os.getcwd()
os.makedirs('Processed_Piezometer_Files', exist_ok=True)

def process_lkup_file(processed_df, lkup_df, lgsn, hds):
    '''Match logger serial number with lookup table and do needed computations '''
    # Get a copy of files to work with
    df  = lkup_df.copy()
    df2 = processed_df.copy()


    # Get row from lookup table that matches log serial number, if records not found program will stop
    try:
        df = df.loc[df['Logger Serial'] == int(lgsn)]
    except IndexError as e:
        print('{}, {}'.format(e.strerror,'Serial Number not in lookup table'))
        sys.exit()   

    # Retain only cols needed from the returned df
    df = df[hds]
    # Add needed cols to main file
    for i,x in enumerate(list(df)):
        df2[x] = df.iloc[0][x]

    # Compute for Uncorrected Polynomial Values mm , Corrected Poly values, Screen Bottom Offset Value mm, Elev. Head, Piezometric Head
    UPV = [] # Empty list to contain Uncorrectd Polynomial values
    CPV = [] # empty list to contain Corrected Polynomial (Pressure Head) values
    SOV = [] # empty list to contain Screen Bottom Offset Values
    EHV = [] # empty list to contain Elevation Head values
    PHV = [] # empty list to contain Piezometric Head values

    
    #'Scan No.','Site Info','Date','Time',Raw Values','Odyssey Values','a','b','c','d','e','f','Offset mm','Elev. Head'

    for row in df2.itertuples():
        col_rwV = float(row[5]); col_a = row[7]; col_b = row[8]; col_c = row[9]; col_d = row[10]
        col_e = row[11]; col_f = row[12];col_rwO = float(row[13]); _EHV = row[14]
                
        # compute for Uncorrectd Polynomial values
        #_UPV = col_a +(col_b * col_rwV)+(col_c *(col_rwV)**2)+(col_d *(col_rwV)**3)+(col_e *(col_rwV)**4)+(col_f *(col_rwV)**5)
        _UPV = col_a +(col_b * col_rwV)+(col_c *(col_rwV)**2)

        # compute for Uncorrectd Offset mm Values
        #_SOV = col_a +(col_b * col_rwO)+(col_c *(col_rwO)**2)+(col_d *(col_rwO)**3)+(col_e *(col_rwO)**4)+(col_f *(col_rwO)**5)
        _SOV = col_rwO

        # compute for Correctd Polynomial values; IF(P3<R3,0,P3-R3+10)
        #if col_rwO == 0:
        #     _CPV = _UPV    
        #elif _UPV == _SOV: # Added this to remove error
        #    _CPV = 0
        if _UPV <= _SOV:
            _CPV = 0
        elif _UPV > _SOV:
            _CPV = (_UPV - _SOV)+13

        #_PHV = _EHV + _CPV # Calculate Piezometric Head
        _PHV = round((_EHV + _CPV) * 0.001, 4) # Calculate Piezometric Head
        
        # Append computed UPV, SOV, CPV, EHV and PHV to lists
        UPV.append(_UPV); SOV.append(_SOV); CPV.append(_CPV) ; EHV.append(_EHV) ; PHV.append(_PHV)

    # Add computed variables in lists as columns to df    
    df2['Uncorrectd Polynomial values mm'] = UPV
    df2['Screen Offset mm'] = SOV
    df2['Pressure Head mm'] = CPV
    df2['Elev. Head mm'] = EHV
    df2['Piezometric Head mm'] = PHV

    # Order of headers in final output file
    list_hds = ['Site Info','Date','Time','Pressure Head mm','Piezometric Head mm','Elev. Head mm','Raw Values','Odyssey Values',
               'a','b','c','d','e','f','Uncorrectd Polynomial values mm','Screen Offset mm'] #'Scan No.' column removed not needed
    # Apply needed order headers yo df
    df2 = df2[list_hds]

    return(df2)

def save_2_xls(df, location, sht_name ):
    ''' Saves dataframe file to MS Excel file '''
    writer = pd.ExcelWriter(location, engine='xlsxwriter') 
    shtName = sht_name
    try:
        df.to_excel(writer, index=False, sheet_name=shtName)

        # Hide columns 
        hide_xls_columns(df,writer,shtName)
    except IOError as e:
        print('\n{}, {}'.format(e.strerror, 'File already open'))
        sys.exit()

def hide_xls_columns(dff,wrt,shtname):
    workbook = wrt.book # Access the workbook
    worksheet= wrt.sheets[shtname] # Access the Worksheet
    worksheet.set_column('G:Q', None, None, {'hidden': True}) # Hide columns 
    wrt.close() # Save file
    
def main():
    print('Please wait, processing data\n')
 
    # Folder path for i/o files
    filesFolder = osdir               # Folder path where the input files are, change this for your drive path    
    #filesFolder = r'D:\Gillian\Datafiles'               # Folder path where the inpu files are, change this for your drive path
    #outputFolder = r'D:\Gillian\Processed_Logger_Files' # Folder part where output file will be saved, change this for your drive path
    outputFolder = r'Processed_Piezometer_Files' # Folder part where output file will be saved, change this for your drive path
    file_ext = '.CSV' # No change unless the input file extension changes

    # Location and file name of lookup table
    lkup_file = r'PyPiezo_coefficients.csv'
    #lkup_file = r'D:\Gillian\look_up_files\PyPiezo_coefficients.csv'

    # Read in lookup file into df
    df_lkup = pd.read_csv(lkup_file)

    # Columns needed from lookup table
    headers_needed = ['a','b','c','d','e','f','Offset mm','Elev. Head']

    #List to hold file names in the folder
    fileNames = []
    os.chdir(filesFolder) # Change to folder to read file from
    # Get all files in the folder into the list holder
    [fileNames.append(os.path.join(filesFolder,files)) for files in os.listdir('.')if files.endswith(file_ext)] 

    # Empty variables
    row_list = []
    header_lst = ['Scan No.','Date','Time','Raw Values','Odyssey Values']

    for i,afile in enumerate(fileNames,1):
        print('Processing file {} of {}'.format(i,len(fileNames)))
        # Empty variables
        fName = ''
        lhd = 0
        hd_info = []
        part2recs = []
        log_sn = ''

        with open(afile,'rt')as f:
            data = csv.reader(f)

            # Read the first 4 rows with records info
            for i,row in enumerate(data):
                if i == 0:
                    Site_name = row[1] # Site name 
                    hd_info.append(Site_name)
                if i == 1:      
                    Site_number = row[1] # Site number
                    hd_info.append(Site_number)
                if i == 2:      
                    logger_desc = row[1] # Logger desc
                    hd_info.append(logger_desc)
                if i == 3:      
                    logger_sn = str(row[1]) # Logger serial 
                    hd_info.append(logger_sn)
                    log_sn = logger_sn
                    # Get name for the output file
                    fName = '{}{}{}'.format('SN_', logger_sn, '.xlsx')
                      
                # Read in the second part - the records
                if i >= 9: # Starts at row #9
                    part2recs.append(row)# Add a row to list
                    lhd += 1 # counting how many rows

            # Add list of records to new df
            df = pd.DataFrame(part2recs, columns=header_lst)        
            
            # Write empty records to remaining cells to site name column
            rec_no = lhd - len(hd_info) # Cells remain to write to
            for i in range(rec_no):
                hd_info.append('')     

            # Insert col Site Info to the dataframe (df)
            df.insert(loc=1, column='Site Info', value=hd_info)

            # Match serial number in lookup table and compute for new variables
            df_processed = process_lkup_file(df, df_lkup, logger_sn, headers_needed)

            # Correct timing error - 24:00:00 to 00:00:00
            df_processed.loc[(df_processed.Time ==' 24:00:00'), 'Time'] = ' 00:00:00'
            #df_processed['Time'] = np.where((df_processed.Time == ' 24:00:00'),'00:00:00',df_processed.Time)
            
            #Save file to xls with pandas module
            logoutfile = os.path.join(outputFolder, fName)
            save_2_xls(df_processed, logoutfile, str(log_sn))

    # All done
    print('\nAll done')


# Main procedure
if __name__ == "__main__":
    main()




 
